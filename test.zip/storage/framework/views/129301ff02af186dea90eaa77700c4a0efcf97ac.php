<?php
echo 'test'
 ?><?php /**PATH C:\Users\Erfan\Desktop\test\resources\views/test.blade.php ENDPATH**/ ?>